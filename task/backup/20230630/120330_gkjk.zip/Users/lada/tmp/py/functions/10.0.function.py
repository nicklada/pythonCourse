#!/usr/bin/env python3
def sayHello():
    print('Hello!')

sayHello()
sayHello()