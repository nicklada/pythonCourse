#!/usr/bin/env python3
if __name__ == '__main__':
    print('Программа запущена самостоятельно')
else:
    print('Меня импортировали в другой модуль')