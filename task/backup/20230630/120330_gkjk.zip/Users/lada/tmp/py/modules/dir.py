#!/usr/bin/env python3
import param
c = 5
#вернет все атрибуты модуля param
print ('Все атрибуты модуля param:', dir(param))

#вернет атрибуты текущего модуля
print('Атрибуты текущего модуля', dir())